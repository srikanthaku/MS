sap.ui.define([
    "sap/ui/core/mvc/ControllerExtension",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast"
], function (
    ControllerExtension,
    Fragment,
    JSONModel,
    MessageToast
) {
    "use strict";

    return ControllerExtension.extend("zoemdisplay.ext.controller.ListReportExt", {

        override: {

            onInit: function () {
                this._oDialog = null;
            }

        },

        /**
         * Event triggered from custom button
         */
        onAddDetailsPress: function () {

            var oView = this.base.getView();

            if (!this._oDialog) {

                Fragment.load({
                    id: oView.getId(),
                    name: "zoemdisplay.ext.fragment.AddDetailsDialog",
                    controller: this
                }).then(function (oDialog) {

                    this._oDialog = oDialog;

                    oView.addDependent(oDialog);

                    var oJSONModel = new JSONModel();

                    oJSONModel.loadData(
                        sap.ui.require.toUrl("zoemdisplay/ext/model/mockData.json")
                    );

                    oDialog.setModel(oJSONModel, "dialog");

                    oDialog.open();

                }.bind(this));

            } else {

                this._oDialog.open();

            }

        },

        /**
         * Close Dialog
         */
        onCloseDialog: function () {

            if (this._oDialog) {
                this._oDialog.close();
            }

        },

        /**
         * Save
         */
        onSaveDialog: function () {

            MessageToast.show("Data Saved Successfully");

            if (this._oDialog) {
                this._oDialog.close();
            }

        },

        /**
         * Tab Selection
         */
        onTabSelect: function (oEvent) {

            var sKey = oEvent.getParameter("key");

            MessageToast.show("Selected Tab : " + sKey);

        },

        /**
         * Button Enable Check
         */
        isAddDetailsEnabled: function () {
            return true;
        },

        /**
         * Button Visible Check
         */
        isAddDetailsVisible: function () {
            return true;
        }

    });

});