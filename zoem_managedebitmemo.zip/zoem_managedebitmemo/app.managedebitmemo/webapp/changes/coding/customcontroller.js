sap.ui.define([
    "sap/ui/core/mvc/ControllerExtension",
    "sap/ui/core/BusyIndicator",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/Text",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/m/Input",
    "sap/m/Label",
    "sap/ui/layout/form/SimpleForm",
    "sap/m/Select",
    "sap/ui/core/Item"
], function (
    ControllerExtension,
    BusyIndicator,
    Dialog,
    Button,
    Text,
    MessageToast,
    MessageBox,
    Input,
    Label,
    SimpleForm,
    Select,
    Item
) {
    "use strict";

    return ControllerExtension.extend(
        "customer.app.variant.customcontroller",
        {
            override: {

                onInit: function () {

                    var iInterval = setInterval(function () {

                        var oDomBtn =
                            document.querySelector(".btn-legacy");

                        if (oDomBtn) {

                            clearInterval(iInterval);

                            oDomBtn.addEventListener(
                                "click",
                                this.onCreateCMRPress.bind(this)
                            );

                        }

                    }.bind(this), 500);

                }
            },

            onCreateCMRPress: function () {

                if (!this._oDialog) {
                    this._createDialog();
                }

                this._oDialog.open();
            },

             _createDialog: function () {

                var that = this;

                var oODataModel = this.getView().getModel("customer.ZCMR_SRV_F4");

                this._oCreditMemoReqType = new sap.m.Select({
                    width: "100%"
                });

                this._oInputReferenceDocument = new sap.m.Input({
                    placeholder: "Enter Reference Billing Document",
                    type: sap.m.InputType.Number
                });

                // Load dropdown values
                oODataModel.read("/Z_OEM_TVARVC_FKART", {
                    filters: [
                        new sap.ui.model.Filter(
                            "varname",
                            sap.ui.model.FilterOperator.EQ,
                            "ZOEM_DMR_TYP"
                        )
                    ],

                    success: function (oData) {

                        // console.log("F4 Data:", oData.results);

                        var oJsonModel = new sap.ui.model.json.JSONModel({
                            items: oData.results
                        });

                        that._oCreditMemoReqType.setModel(oJsonModel, "f4");

                        that._oCreditMemoReqType.bindItems({
                            path: "f4>/items",
                            templateShareable: false,
                            template: new sap.ui.core.Item({
                                key: "{f4>low}",
                                text: "{f4>low}"
                            })
                        });
                    },

                    error: function (oError) {
                        console.log("Error loading dropdown", oError);

                        sap.m.MessageBox.error(
                            "Unable to load Credit Memo Request Types"
                        );
                    }
                });

                var oForm = new sap.ui.layout.form.SimpleForm({
                    editable: true,
                    content: [
                        new sap.m.Label({
                            text: "Debit Memo Request Type",
                            required: true
                        }),
                        this._oCreditMemoReqType,

                        new sap.m.Label({
                            text: "Reference Billing Document",
                            required: true
                        }),
                        this._oInputReferenceDocument
                    ]
                });

                this._oDialog = new sap.m.Dialog({
                    title: "Create Debit Memo Request",
                    content: [oForm],

                    beginButton: new sap.m.Button({
                        text: "Create",
                        press: function () {
                            that._onCreateCreditMemo();
                        }
                    }),

                    endButton: new sap.m.Button({
                        text: "Cancel",
                        press: function () {
                            that._oDialog.close();
                        }
                    })
                });

                this._oDialog.open();
            },
            _onCreateCreditMemo: function () {

                var oView = this.base.getView();
                var that = this;

                var sReqType = this._oCreditMemoReqType.getSelectedKey();
                var sRefDoc = this._oInputReferenceDocument.getValue();

                if (!sReqType || !sRefDoc) {
                    sap.m.MessageBox.error("Please enter all required fields.");
                    return;
                }

                var oPayload = {
                    SalesDocumentType: sReqType,
                    BillingDocument: sRefDoc
                };

                var oModel = oView.getModel("customer.ZCMR_SRV_V4");

                if (!oModel) {
                    sap.m.MessageBox.error("OData V4 Model not found.");
                    return;
                }

                this._oDialog.setBusy(true);

                try {

                    var oListBinding = oModel.bindList("/ZC_CREDIT_MEMO_H");
                    var oContext = oListBinding.create(oPayload);
                     var oMessageManager = sap.ui.getCore().getMessageManager();
                    // Clear old messages
                    oMessageManager.removeAllMessages();
                    oContext.created()
                        .then(function () {

                            that._oDialog.setBusy(false);

                            var aMessages = sap.ui.getCore()
                                .getMessageManager()
                                .getMessageModel()
                                .getData();

                            if (aMessages && aMessages.length > 0) {

                                var oMsg = aMessages[0];

                                switch ((oMsg.type || "").toLowerCase()) {

                                    case "error":
                                        sap.m.MessageBox.error(oMsg.message);
                                        break;

                                    case "warning":
                                        sap.m.MessageBox.warning(oMsg.message);
                                        break;

                                    case "information":
                                    case "info":
                                        sap.m.MessageBox.information(oMsg.message);
                                        break;

                                    default:
                                        sap.m.MessageBox.success(oMsg.message, {
                                            onClose: function () {
                                                that._clearDialogFields();
                                                that._oDialog.close();
                                            }
                                        });
                                        break;
                                }

                            } else {

                                sap.m.MessageBox.success("Record created successfully", {
                                    onClose: function () {
                                        that._clearDialogFields();
                                        that._oDialog.close();
                                    }
                                });

                            }

                        })
                        .catch(function (oError) {

                            that._oDialog.setBusy(false);

                            console.error("Backend Error:", oError);

                            var aMessages = sap.ui.getCore()
                                .getMessageManager()
                                .getMessageModel()
                                .getData();

                            if (aMessages && aMessages.length > 0) {

                                sap.m.MessageBox.error(
                                    aMessages[0].message,
                                    {
                                        onClose: function () {
                                            that._clearDialogFields();
                                        }
                                    }
                                );

                            } else {

                                sap.m.MessageBox.error(
                                    oError?.error?.message ||
                                    oError?.message
                                );

                            }

                        });

                } catch (oError) {

                    this._oDialog.setBusy(false);

                    console.error(oError);

                    sap.m.MessageBox.error(
                        oError.message
                    );
                }
            },

            _clearDialogFields: function () {
                // this._oInputSalesOrg.setValue("");
                // this._oInputDistChannel.setValue("");
                // this._oInputDivision.setValue("");
                if (this._oInputReferenceDocument) {
                    this._oInputReferenceDocument.setValue("");
                }
            }
        }
    );
});